# ZoracleFlux 1.0.0rc2

ZoracleFlux is an **offline-first Python developer CLI** that checks explicitly
declared behavioral relations against a small, transparent supported subset.
It produces bounded evidence, not formal proofs.

## Quickstart

```powershell
py -3.10 -m venv .venv
.venv\Scripts\python -m pip install --requirement requirements.lock
.venv\Scripts\python -m pip install .
zoracleflux doctor --json
zoracleflux check --json
zoracleflux generate
zoracleflux pilot --json
pytest
```

`check` executes only the packaged trusted fixture. `check --source path.py`
parses declarations but deliberately never imports or executes external code.
Unknown or malformed `@relation` declarations fail closed. `--json` output has
schema version `1`; invalid, unsupported, failed, or timeout results return
nonzero status.

`pilot` runs the same synthetic fixture locally and records bounded evidence in
SQLite under `.zoracleflux\pilot.sqlite3`. It accepts no source code, credentials,
network destination, or model input and is not customer validation.

## Scope and boundaries

V1 supports Python 3.10â€“3.12, deterministic local execution, and 11 relation
templates over the included pure transformations. It does not promise arbitrary
repository understanding, formal verification, sandboxing, hosted availability,
security certification, model quality, or customer-data processing. Optional
model assistance is not shipped and is never required.

## Release evidence

Run `python evaluation\run_evaluation.py` to reproduce the held-out fixture
report. See `RELEASE_READINESS.md`, `FINAL_GAP_REGISTER.md`, `docs\SECURITY.md`,
and `docs\LIMITATIONS.md`.

## First five commands

```powershell
python -m pip install --requirement requirements.lock
python -m pip install .
zoracleflux doctor --json
zoracleflux check --json
zoracleflux pilot --json
```
